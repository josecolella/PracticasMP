Entrega: Se tiene que ejecutar make. Despues tendremos las bibliotecas, objetos, y binarios
	Se han creado binarios para el ejercicio 1, ejercicio2, ejercicio 3, ejericio 4, ejercicio 5, y ejericio 6

	