/*********************************************************************/
// METODOLOGIA DE LA PROGRAMACION
// GRADO EN INGENIERIA INFORMATICA
//
// CURSO 2012-2013
// (C) FRANCISCO JOSE CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION E INTELIGENCIA ARTIFICIAL
//
// RELACION DE PROBLEMAS 2
// EJERCICIO 7
//
// Ejercicio 02-07
//
/*********************************************************************/

#include <iostream>
#include <iomanip>
using namespace std; 

/******************************************************************/
/******************************************************************/

enum TipoRedimension {DeUnoEnUno, EnBloquesDeN, Duplicando};

/******************************************************************/
/******************************************************************/

class Almacen 
{
private: 
	int * data;  // Para almacenar los datos
	int tam;	 // Numero maximo de casillas
	int usados;  // Casillas usadas

	static const int tam_def = 10; // Capacidad inicial, por defecto 
	static const int N = 5;        // Tamanio del bloque para redimensionar

public: 
	// Constructor sin argumentos
	Almacen (void) : tam (tam_def), usados (0) 
	{
		data = new int[tam]; // La memoria la pide el constructor
	}
	// Constructor con argumentos
	Almacen (int tam_inicial) : tam (tam_inicial), usados (0) 
	{
		data = new int[tam]; // La memoria la pide el constructor
	}
	void Pinta (void) 
	{
		for (int i=0; i<usados; i++) 
			cout << setw(3) << data[i] << " "; 
	}
	int Capacidad (void)
	{
		return (tam);
	}
	int NumDatosGuardados(void)
	{
		return (usados);
	}
	static int TamBloque (void)
	{
		return (N);
	}
	void Aniade (int valor)
	{
		data [usados] = valor;
		usados++;
	}
	void RedimensionaAlmacen (TipoRedimension tipo)
	{
		switch (tipo) {
			case(DeUnoEnUno):	tam++; // nuevo tamanio: se incrementa en 1 casillas
								break;
			case(EnBloquesDeN):	tam+=N; // nuevo tamanio: se incrementa en N casillas
								break;
			case(Duplicando):  	tam*=2; // nuevo tamanio: se duplica
								break;
		}
		
		int * tmp = new int[tam]; // nuevo almacen 
		for (int i=0; i<usados; i++) tmp[i]=data [i]; // copia
			
		// memcpy (tmp, data, usados*sizeof(int)); // copia mejorada

		delete [] data; // libera el antiguo
		data = tmp; // reasignacion
	}

};

/******************************************************************/
/******************************************************************/

// Lee el tipo de redimensionamiento que se empleara
TipoRedimension LeeTipoRedimension (void)
{
	TipoRedimension tipo; 
	int opcion; 

	do {
		cout << "Introducir tipo de redimensionamiento del almacen:\n ";
		cout << "   1.- De uno en uno\n ";
		cout << "   2.- En bloques de tamano " << Almacen::TamBloque() << "\n ";
		cout << "   3.- Duplicando\n ";
		cout << "Opcion: "; 
		cin >> opcion;
	}
	while ((opcion <1) || (opcion > 3));

	switch (opcion) { 
		case (1):	tipo = DeUnoEnUno;
					break;
		case (2):	tipo = EnBloquesDeN;
					break;
		case (3):	tipo = Duplicando;
					break; 
	}
	return (tipo); 
}

/******************************************************************/
/******************************************************************/

int main (void)
{
	Almacen almacen (5);
	
	TipoRedimension tipo = LeeTipoRedimension (); 

	int valor;

	cout << "Introducir un valor (para finalizar, introducir un negativo): "; 
	cin >> valor;

	while (valor >= 0) {

		if (almacen.NumDatosGuardados() == almacen.Capacidad()) { // redimensionar almacen

			almacen.RedimensionaAlmacen (tipo);

			cout << "Se ha redimensionando almacen hasta " << almacen.Capacidad() << " casillas\n";
		}

		almacen.Aniade (valor);

		cout << "Introducir un valor (para finalizar, introducir un negativo): "; 
		cin >> valor;

	}

    almacen.Pinta(); 

	// Queda pendiente la liberacion de memoria (tarea del destructor) 

	char c;
	cin >> c; 

	return (0);
}

